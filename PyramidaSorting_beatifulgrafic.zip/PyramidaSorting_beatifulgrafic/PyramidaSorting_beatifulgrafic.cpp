// PyramidaSorting_beatifulgrafic.cpp: ���������� ����� ����� ��� ����������� ����������.
//

#include "stdafx.h"
#include <iostream>
#include <ctime>

using namespace std;

void grafic_left_side(int aray[],int n);
void grafic_right_side(int aray[],int n);
void pyramid(int aray[], int n);
void grafic_both_side_pyramid(int aray[], int n);
void pyramid_conversely(int aray[], int n);
void pyramid_ordinary(int aray[], int n);
void pyramid_both_side_ordinary(int aray[], int n);
void output(int aray[], int n);

int _tmain(int argc, _TCHAR* argv[])
{
	srand(time(NULL));
	int i = 0,
		l,
		n = rand()%9+1,
		r,
		c,
		iter = NULL,
		swap = 0,
		s = n,
		*aray = new int[n];
	int max = aray[0];
	while (i < n)
	{
		i++;
		aray[i] = 1 + rand() % n;
		while (iter < i)
		{
			if (aray[i] == aray[iter])
			{
				aray[i] = 1 + rand() % n;
				iter = -1;
			}
			iter++;
		}iter = 0;
		cout << "aray[" << i << "]= " << aray[i] << endl;
	}
	i = 0;
	cout << endl << endl;
	cout << endl << endl;

	for (; s >= 1; s--)
	{
	while (aray[1] != max)
	{
		while (i < s)
		{
			i++;
			if (aray[i] < aray[2 * i] && (2 * i) <= s)
			{
				swap = aray[i];
				aray[i] = aray[2 * i];
				aray[2 * i] = swap;
			}
			if (aray[i] < aray[2 * i + 1] && (2 * i + 1) <= s)
			{
				swap = aray[i];
				aray[i] = aray[2 * i + 1];
				aray[2 * i + 1] = swap;
			}
			if (aray[i] > max)max = aray[i];

		}
		i = 0;
	}
	max = aray[0];
		swap = aray[1];
		aray[1] = aray[s];
		aray[s] = swap;
}

	i = 0;
	iter = 0;
	output(aray, n);
	//pyramid_conversely(aray, n);
	//grafic_both_side_pyramida(aray, n);
	//pyramid_both_side_ordinary(aray, n);
	system("pause");
	return 0;
}

void pyramid_ordinary(int aray[], int n)
{
	int i = 1,
		iter,
		temp_ar = n + (n - 1),
		*temp_ar1 = new int[temp_ar],
		*temp_ar2 = new int[temp_ar],
		temp = ((n + (n - 1)) % 2 == 1) ? ((n + (n - 1)) / 2 + 1) : ((n + (n - 1)) / 2);
	cout << endl << endl;
	while (i <= n)
	{
		iter = temp;
		while (iter > 0)
		{
			if (aray[i] >= iter)
			{
				temp_ar2[iter] - aray[i];
				cout << aray[i];
			}
			else if ((temp_ar1[iter] == aray[i - 1])&&i-1!=0)
				cout << "_";
			cout << " ";
			iter--;
		}
		for (int it = 0; it < temp; it++)
		{
			temp_ar1[it] = temp_ar2[it];
		}delete[] temp_ar2;
		temp_ar2 = new int[temp];
		i++; cout << endl;
	}
}

void pyramid_both_side_ordinary(int aray[], int n)
{
	int i = 0,
		iter,
		temp_ar = n + (n - 1),
		*temp_ar1 = new int[temp_ar],
		*temp_ar2 = new int[temp_ar],
		temp = ((n + (n - 1)) % 2 == 1) ? ((n + (n - 1)) / 2 + 1) : ((n + (n - 1)) / 2);
	cout << endl << endl;
	while (i < n)
	{
		iter = temp;
		while (iter > 0)
		{
			if (aray[i] >= iter)
			{
				temp_ar2[iter] - aray[i];
				cout << aray[i];
			}
			else if ((temp_ar1[iter] == aray[i - 1])&&i-1!=0)
				cout << "_";
			cout << " ";
			iter--;
		}
		for (int it = 0; it < temp; it++)
		{
			temp_ar1[it] = temp_ar2[it];
		}delete[] temp_ar2;
		temp_ar2 = new int[temp];
		i++; cout << endl;
	}
	i = n - 2;
	while (i >= 0)
	{
		iter = temp;
		while (iter > 0)
		{
			if (aray[i] >= iter)
			{
				temp_ar2[iter] - aray[i];
				cout << aray[i];
			}
			else if ((temp_ar1[iter] == aray[i - 1])&& i-1!=0)
				cout << "_";
			cout << " ";
			iter--;
		}
		for (int it = 0; it < temp; it++)
		{
			temp_ar1[it] = temp_ar2[it];
		}delete[] temp_ar2;
		temp_ar2 = new int[temp];
		i--; cout << endl;
	}
}
void pyramid(int aray[], int n)
{
	int i = 0,
		iter;
	cout << endl << endl;
	while (i < n)
	{
		i++;
		iter = n;
		while (iter >0)
		{

			if (aray[i] >= iter)
				cout << aray[i];
			else if (iter == 1)
			{
				iter--;
				continue;
			}
			else
				cout << " ";
			if (aray[i] < 10)
				cout << " ";
			cout << " ";
			iter--;
		}
		iter = 1;
		while (iter <= aray[i])
		{
			cout << aray[i];
			if (iter == aray[i])
			{
				iter++;
				continue;
			}
			if (aray[i] < 10)
				cout << " ";
			cout << " ";
			iter++;
		}
		cout << endl;
	}
}
void grafic_both_side_pyramid(int aray[], int n)
{
	int i = 0, 
		iter = 0;
	cout << endl << endl;
	while (i < n)
	{
		i++;
		cout << "aray[" << i << "]= " << aray[i] << endl;
	}
	i = 0;
	cout << endl << endl;


	while (i < n)
	{
		i++;
		iter = n;
		while (iter >0)
		{

			if (aray[i] >= iter)
				cout << aray[i];
			else if (iter == 1)
			{
				iter--;
				continue;
			}
			else
				cout << " ";
			if (aray[i] < 10)
				cout << " ";
			cout << " ";
			iter--;
		}
		iter = 1;
		while (iter <= aray[i])
		{

			cout << aray[i];
			if (iter == aray[i])
			{
				iter++;
				continue;
			}
			if (aray[i] < 10)
				cout << " ";
			cout << " ";
			iter++;
		}
		cout << endl;
	}

	i = n;

	while (i >0)
	{
		iter = n;
		while (iter > 0)
		{

			if (aray[i] >= iter)
				cout << aray[i];
			else if (iter == 1)
			{
				iter--;
				continue;
			}
			else
				cout << " ";
			if (aray[i] < 10)
				cout << " ";
			cout << " ";
			iter--;
		}
		iter = 1;
		while (iter <= aray[i])
		{

			cout << aray[i];
			if (iter == aray[i])
			{
				iter++;
				continue;
			}
			if (aray[i] < 10)
				cout << " ";
			cout << " ";
			iter++;
		}
		i--;
		cout << endl;
	}
}

void pyramid_conversely(int aray[], int n)
{
	int iter,
	i = n;
	cout << endl << endl;

	while (i > 0)
	{
		iter = 1;
		while (iter <= n)
		{
			if (iter <= aray[i])
				cout << aray[i];
			else cout << " ";
			cout << " ";
			iter++;
		}

		iter = n;
		while (iter > 0)
		{

			if (aray[i] >= iter)
				cout << aray[i];
			else if (iter == 1)
			{
				iter--;
				continue;
			}
			else
				cout << " ";
			cout << " ";
			iter--;
		}
		iter = n;
		while (iter > 0)
		{

			if (aray[i] >= iter)
				cout << aray[i];
			else if (iter == 1)
			{
				iter--;
				continue;
			}
			else
				cout << " ";
			cout << " ";
			iter--;
		}iter = n;
		while (iter > 0)
		{

			if (aray[i] >= iter)
				cout << aray[i];
			else if (iter == 1)
			{
				iter--;
				continue;
			}
			else
				cout << " ";
			cout << " ";
			iter--;
		}
		i--;
		cout << endl;
	}

	i = 0;

	while (i <n)
	{
		i++;
		iter = 1;
		while (iter <= n)
		{
			if (iter <= aray[i])
				cout << aray[i];
			else cout << " ";
			cout << " ";
			iter++;
		}
		iter = n;
		while (iter > 0)
		{

			if (aray[i] >= iter)
				cout << aray[i];
			else if (iter == 1)
			{
				iter--;
				continue;
			}
			else
				cout << " ";
			if (aray[i] < 10)
				cout << " ";
			//cout << " ";
			iter--;
		}
		iter = n;
		while (iter > 0)
		{

			if (aray[i] >= iter)
				cout << aray[i];
			else if (iter == 1)
			{
				iter--;
				continue;
			}
			else
				cout << " ";
			if (aray[i] < 10)
				cout << " ";
			//cout << " ";
			iter--;
		}
		iter = n;
		while (iter > 0)
		{

			if (aray[i] >= iter)
				cout << aray[i];
			else if (iter == 1)
			{
				iter--;
				continue;
			}
			else
				cout << " ";
			if (aray[i] < 10)
				cout << " ";
			//cout << " ";
			iter--;
		}
		cout << endl;
	}
}

void grafic_left_side(int aray[],int n)
{
	int i = 0,
		iter;
	cout << endl << endl;
	while (i < n)
	{
		i++;
		iter = 1;
		while (iter <= aray[i])
		{

			cout << aray[i] << " ";
			iter++;
		}
		cout << endl;
	}
}

void grafic_right_side(int aray[],int n)
{
	int i = 0,
		iter;
	cout << endl << endl;
	while (i < n)
	{
		i++;
		iter = n;
		while (iter >0)
		{

			if (aray[i] >= iter)
				cout << aray[i];
			else
				cout << " ";
			cout << " ";
			iter--;
		}
		cout << endl;
	}
}
void output(int aray[], int n)
{
	int i = 0;
	cout <<endl << endl;
	while (i < n)
	{
		i++;
		cout << "aray[" << i << "]= " << aray[i] << endl;
	}
}
/*
const int n = 10;
int aray[n],
i = 0,
l,
r,
c,
swap = 0;
while (i < n)
{
aray[i] = 1 + rand() % 10;
cout << "aray[" << i + 1 << "]= " << aray[i] << endl;
i++;
}
i = 0;
l = 0;
r = n;
do{
c = (l + r) / 2;
l = (l + c) / 2;
r = (r + c) / 2;
} while (true);





for (int iter = n - 1,iter1=0; iter >= 0; iter--,iter1++)
{
while (i < n)
{
if (aray[2 * i] > aray[i])
{
swap = aray[2 * i];
aray[2 * i] = aray[i];
aray[i] = swap;
}
if (aray[2 * i + 1] > aray[i])
{
swap = aray[2 * i + 1];
aray[2 * i + 1] = aray[i];
aray[i] = swap;
}
i++;
}
i = 0;
swap = aray[iter];
aray[iter] = aray[iter1];
aray[iter1] = swap;
}
cout << endl << endl;
i = 0;
while (i<n)
{
cout << "aray[" << i + 1 << "]= " << aray[i] << endl;
i++;
}//////*/